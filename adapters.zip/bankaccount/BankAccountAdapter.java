package us.hypermediocrity.springclean.adapter.bankaccount;

import us.hypermediocrity.springclean.domain.entity.FundTransfer;
import us.hypermediocrity.springclean.domain.entity.Money;
import us.hypermediocrity.springclean.domain.port.PaymentSystem;
import us.hypermediocrity.springclean.domain.port.TransferResponse;

public class BankAccountAdapter implements PaymentSystem {

  @Override
  public TransferResponse request(Money amount, FundTransfer transfer) {
    // TODO Auto-generated method stub
    return null;
  }

}
